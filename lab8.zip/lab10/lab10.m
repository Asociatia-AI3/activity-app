y=[2, 3, 5]
%plot(y);

x = [6 8 6]
y = [2 3 5]
%plot(x, y)

y = [2 3 5]
%plot(y, '*')

y = -2 + 5*i
%plot(y, '*')

y = [2 3 1;1 3 4;4 3 5]
%plot(y)
%pause;

x = [1 3 6]
y = [2 3 1;1 3 4;4 3 5]
%plot(x,y)
%pause;

x = [1 2 3;2 2 1;3 2 1]
y = [2 3 1;1 3 4;4 3 5]
%plot(x,y)
%pause;

x = [1 2 3;2 2 1;3 2 1]
y = [2 3 1;1 3 4;4 3 5]
%plot(x,y,'*')
%pause;

x1 = [1 2 4]
y1 = [2 1 3]
x2 = [1 6]
y2 = [2 3]
%plot(x1,y1,x2,y2)
%pause;

x = 1:1000;
y = x.^3;
%plot(x,y)
%pause;
%semilogy(x, y)

t = 0:0.001:0.02;
f = sin(2*pi*50*t);
g=f+.2;
%plot(t, f, '-.g', t, g, '*r')
%pause;

x = 0:0.1:10;
y1 = x.^3.*sin(x);
y2 = x.^3.*cos(x);
%plot(x, y1, 'r', 'linewidth', 2)
%pause;
%grid;
%hold on;
%plot(x, y2, '*b', 'markersize', 5)
%legend('y_1 = x^3 sin(x)', 'y_2 = x^3 cos(x)', 'location', 'northwest')
%xlabel('x'), ylabel('y_1 si y_2')
%title('Exemplu de grafic 2D')

x=0:0.1:100;
y=(x+1)./log(x);
%plot(x,y)
%axis([0 inf 0 inf])
%axis([0 15 0 15])
x=0:0.1:100;
y=(x+1)./log(x);
%plot(x, y)
%axis([0 inf 0 inf])
%pause;
clear;

t=0:0.1:2*pi;
x=sin(t);
y=cos(t);
%plot(x,y)
%axis equal;
%pause;
clear;

t=0:0.01:2*pi
f=sin(2*t).*cos(2*t)
%polar(t, f)
clear;

x1 = [0 3 2 -1]
y1 = [-1 -1 2 2]
x2 = [3 5 2]
y2 = [-1 3 2]
%fill(x1, y1, 'b', x2, y2, 'g')
%grid ;
clear;


