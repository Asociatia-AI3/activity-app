import matplotlib.pyplot as plt
import numpy as np

y = [2, 3, 5]
##plt.plot(y)
###plt.show()
##plt.plot(y, '*')
###plt.show()
x = [6, 8, 6]
##plt.plot(x, y)
###plt.show()
y=[[2, 3, 1], [1, 3, 4], [4, 3, 5]]
##plt.plot(y)
###plt.show()

x = [[1, 2, 3], [2, 2, 1], [3, 2, 1]]
y = [[2, 3, 1], [1, 3, 4], [4, 3, 5]]
##plt.plot(x, y)
###plt.show()
##plt.plot(x, y, '*')
###plt.show()

x1 = [1, 2, 4]
y1 = [2, 1, 3]
x2 = [1, 6]
y2 = [2, 3]
##plt.plot(x1, y1, x2, y2)
###plt.show()

x = np.arange(-np.pi, np.pi, 0.01)
f = x**2*np.sin(x)+np.log(np.abs(x))
##plt.figure(figsize=(5,2))
##plt.plot(x, f, 'r', linewidth=4)
##plt.xlabel('x')
##plt.ylabel('f(x)=x^2+sin(x)')
##plt.title('Graficul functiei f')
##plt.grid(True)
##plt.show()

x = np.arange(-np.pi, np.pi, 0.01)
f = x**2*np.sin(x)+np.log(np.abs(x))
##plt.figure(figsize=(5,2))
##plt.plot(x, f, 'r', linewidth=4)
##plt.xlabel('x')
##plt.ylabel('f(x)=x^2+sin(x)')
##plt.title('Graficul functiei f')
##plt.grid(True)
##plt.xlim(-10, 10)
##plt.ylim(-8, 8)
##plt.show()

t = np.arange(0, 0.02, 0.001)
f = np.sin(100*np.pi*t)
g=f+0.2
##plt.plot(t, f, '-.g', '*r')
##plt.show()

x = np.arange(0, 10, 0.1)
y1 = x**3*np.sin(x)
y2 = x**2*np.cos(x)
##plt.figure(figsize=(5,2))
##plt.plot(x, y1, 'r', linewidth=4, label='y1=x^3*sin(x)')
##plt.grid(True)
##plt.plot(x, y2, 'b*', linewidth=5, label='y2=x^2*cos(x)')
##plt.legend(loc='upper left')
##plt.show()

x = np.arange(0.00001, 100, 0.1)
y = (x + 1) / np.log(x)
#plt.figure(figsize=(5, 2))
#plt.plot(x, y)
#plt.xlim(0, 15)
#plt.ylim(0, 15)
#plt.show()

t = np.linspace(0, 2*np.pi, 100)
x = np.cos(t)
y = np.sin(t)
#plt.figure(figsize=(5, 5))
#plt.plot(x, y)
#plt.show()

t = np.arange(0, 2*np.pi + 0.1, 0.1)
x = np.cos(t)
y = np.sin(t)
#plt.figure(figsize=(5, 5))
#plt.plot(x, y)
#plt.show()

t = np.arange(0, 2*np.pi, 0.1)
x = np.cos(t)
y = np.sin(t)
#plt.figure(figsize=(5, 5))
#plt.plot(x, y)
#plt.show()

t = np.linspace(-3, 3, 1000)
x = (t**2) * np.sin(t)
y = 2 * t
#plt.figure(figsize=(8, 6)) # Crearea unei figuri de dimensiune 8x6
#plt.plot(x, y, label=r'$x=t^2\sin(t), y=2t$')
#plt.xlabel('Axa X')
#plt.ylabel('Axa Y')
#plt.grid(True)
#plt.legend()
#plt.show()

t = np.arange(0,2*np.pi,0.01)
f = np.sin(2*t)*np.cos(2*t)
#plt.figure(figsize=(4,4))
#plt.polar(t, f, 'r', linewidth=2)
#plt.savefig('fig16_p.png')

y = [0.1, 0.4, 0.2, 0.3]
x = ['A', 'B', 'C', 'D']
plt.figure(figsize=(4, 4))
plt.pie(y, labels=x, autopct='%1.1f%%', colors=['magenta', 'red', 'purple', 'pink'])
plt.savefig('fig18_p.png')

x = [1, 2, 3, 4, 5, 6, 7, 8]
y = [2, 3, 1, 6, -4, 0, 8, 2]
plt.figure(figsize=(4, 4))
plt.bar(x, y, alpha=0.5)
plt.plot(x, y)
plt.grid(True)
plt.savefig('fig19_p.png')

x = np.arange(-3, 3, 0.3)
y = np.random.randn(10000, 1)
plt.figure(figsize=(4, 4))
plt.hist(y, x, edgecolor='black')
plt.savefig('fig20_p.png')

t = np.arange(0, 2*np.pi, 0.1)
x = np.cos(t)
y = np.sin(t)
plt.figure(figsize=(5, 5))
plt.plot(x, y)
plt.savefig('fig21_p.png')

t = np.arange(0, 2*np.pi + 0.1, 0.1)
x = np.cos(t)
y = np.sin(t)
plt.figure(figsize=(5, 5))
plt.plot(x, y)
plt.savefig('fig22_p.png')

t = np.linspace(0, 2*np.pi, 100)
x = np.cos(t)
y = np.sin(t)
plt.figure(figsize=(5, 5))
plt.plot(x, y)
plt.savefig('fig23_p.png')

t = np.linspace(-3, 3, 1000)
x = (t**2) * np.sin(t)
y = 2 * t
plt.figure(figsize=(8, 6))
plt.plot(x, y)
plt.savefig('fig24_p.png')

x = [1, 2, 3, 4, 5, 6, 7, 8]
y = [2, 3, 1, 6, -4, 0, 8, 2]
plt.figure(figsize=(2, 2))
plt.bar(x, y)
plt.grid(True)
plt.savefig('fig25_p.png')

x1 = [0, 3, 2, -1]
y1 = [-1, -1, 2, 2]
x2 = [3, 5, 2]
y2 = [-1, 3, 2]
plt.figure(figsize=(2, 2))
plt.fill(x1, y1, 'b', x2, y2, 'g')
plt.grid(True)
plt.savefig('fig26_p.png')

x = np.arange(0, 6, 0.2)
y = np.sin(x)
a = np.random.rand(np.size(x)) / 5
plt.figure(figsize=(4, 4))
plt.errorbar(x, y, a)
plt.savefig('fig27_p.png')

x = np.arange(0, 6, 0.2)
x_new = x[:len(x)-1]
y = np.sin(x)
plt.figure(figsize=(4, 4))
plt.stairs(y, x_new)
plt.savefig('fig28_p.png')
fig = plt.figure()