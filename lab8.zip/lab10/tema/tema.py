import matplotlib.pyplot as plt
from mpl_toolkits import mplot3d
import numpy as np
import os

output_dir = "figuri"
fig_counter = 1
def get_next_fig_counter():
    global fig_counter
    current = fig_counter
    fig_counter += 1
    return current

def save_fig(fig):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    counter = get_next_fig_counter()
    name = f"fig{counter}_3d.png"
    if name in os.listdir(output_dir):
        print(f"Fig {name} already exists!")
    else:
        fig.savefig(os.path.join(output_dir, name))

# 1. Funcție exponențială crescătoare
# f(x) = e^(0.3x) pe [-5, 5]
fig1 = plt.figure()
x1 = np.linspace(-5, 5, 100)
y1 = np.exp(0.3 * x1)
plt.plot(x1, y1, color='purple', label='$e^{0.3x}$') # Culoare mov
plt.title("1. Exponențială Crescătoare")
plt.grid(True)
plt.legend()
save_fig(fig1)

# 2. Funcție logaritmică în bază 10
# g(x) = log10(x) pe [0.1, 10]
fig2 = plt.figure()
x2 = np.linspace(0.1, 10, 100)
y2 = np.log10(x2)
plt.plot(x2, y2, linestyle='--', color='blue', label='$\log_{10}(x)$') # Linie punctata
plt.title("2. Funcție Logaritmică")
plt.legend()
save_fig(fig2)

# 3. Funcție sinus amortizată
# f(x) = e^(-0.5x) * sin(3x) pe [0, 10]
fig3 = plt.figure()
x3 = np.linspace(0, 10, 200) # Mai multe puncte pentru curbura fina
y3 = np.exp(-0.5 * x3) * np.sin(3 * x3)
# markevery=20 pune un marker la fiecare al 20-lea punct din cele generate
plt.plot(x3, y3, color='green', marker='o', markevery=20, label='$e^{-0.5x}\sin(3x)$')
plt.title("3. Sinus Amortizat")
plt.legend()
save_fig(fig3)

# 4. Funcție parabolică deplasată
# f(x) = (x - 2)^2 + 1 pe [-2, 6]
fig4 = plt.figure()
x4 = np.linspace(-2, 6, 100)
y4 = (x4 - 2)**2 + 1
plt.plot(x4, y4, label='$(x-2)^2 + 1$')
# Desenam axele
plt.axhline(0, color='black', linewidth=1) # Axa X (y=0)
plt.axvline(0, color='black', linewidth=1) # Axa Y (x=0)
plt.title("4. Parabolă Deplasată")
plt.legend()
save_fig(fig4)

# 5. Funcție radical și funcție logaritmică
# f(x) = sqrt(x), g(x) = ln(x+1) pe [0, 10]
fig5 = plt.figure()
x5 = np.linspace(0, 10, 100)
y5_1 = np.sqrt(x5)
y5_2 = np.log(x5 + 1) # np.log este logaritm natural (ln)
plt.plot(x5, y5_1, color='red', label='$\sqrt{x}$')
plt.plot(x5, y5_2, color='blue', label='$\ln(x+1)$')
plt.legend()
plt.title("5. Radical vs Logaritm")
save_fig(fig5)

# 6. Funcție definită pe părți
# 2-x pentru x < 1 si ln(x) pentru x >= 1 pe [0, 5]
fig6 = plt.figure()
# Interval 1: [0, 1]
x6_1 = np.linspace(0, 1, 50)
y6_1 = 2 - x6_1
# Interval 2: [1, 5]
x6_2 = np.linspace(1, 5, 50)
y6_2 = np.log(x6_2)
# Plotare cu stiluri diferite
plt.plot(x6_1, y6_1, 'r-', label='$2-x$')       # Linie continua rosie
plt.plot(x6_2, y6_2, 'b--', label='$\ln(x)$')   # Linie intrerupta albastra
plt.legend()
plt.title("6. Funcție pe părți")
save_fig(fig6)

# 7. Diagramă de tip BAR
fig7 = plt.figure()
V = [12, 7, 9, 14, 6, 10]
plt.bar(range(len(V)), V, color='skyblue', edgecolor='black')
plt.title("7. Diagramă BAR")
save_fig(fig7)

# 8. Diagramă de tip PIE
fig8 = plt.figure()
U = [25, 15, 20, 30, 10]
plt.pie(U, labels=['A', 'B', 'C', 'D', 'E'], autopct='%1.1f%%')
plt.title("8. Diagramă PIE")
save_fig(fig8)

# Afisarea (opțional, dacă rulezi local și vrei să vezi ferestrele)
# plt.show()