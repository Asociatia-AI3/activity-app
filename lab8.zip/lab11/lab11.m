%t=0:pi/50:10*pi;
%plot3(sin(t), cos(t), t)

% Definim variabilele globale la �0�6nceput
global fig_counter;
fig_counter = 34;
global output_dir;
output_dir = "figuri";

% Func�0�4ie pentru incrementarea contorului
function current = get_next_fig_counter()
    global fig_counter;
    current = fig_counter;
    fig_counter = fig_counter + 1;
endfunction

% Func�0�4ie pentru salvarea figurii
function save_fig(h_fig)
    global output_dir;

    % Verific�0�0 dac�0�0 directorul exist�0�0 (7 �0�6nseamn�0�0 director)
    if exist(output_dir, "dir") ~= 7
        mkdir(output_dir);
    endif

    counter = get_next_fig_counter();

    % Construie�0�2te numele fi�0�2ierului
    fname = sprintf("fig%d_3d.png", counter);

    % Construie�0�2te calea complet�0�0 (similar cu os.path.join)
    filepath = fullfile(output_dir, fname);

    % Verific�0�0 dac�0�0 fi�0�2ierul exist�0�0 deja (2 �0�6nseamn�0�0 fi�0�2ier)
    if exist(filepath, "file") == 2
        printf("Fig %s already exists!\n", fname);
    else
        % Salveaz�0�0 figura
        % h_fig: handle-ul figurii
        % filepath: calea
        % "-dpng": formatul (po�0�4i schimba rezolu�0�4ia cu "-r300")
        print(h_fig, filepath, "-dpng");
    endif
endfunction

% === 1. Meshz (din imaginea cu meshz) ===
h_fig = figure(1);
[x y] = meshgrid(-2:0.2:2, -2:0.2:2);
z = x .* exp(-x.^2 - y.^2);
meshz(x,y,z);
save_fig(h_fig);

% === 2. Comet3 (din imaginea cu t si comet3) ===
h_fig = figure(2);
t = 0:pi/50:10*pi;
comet3(t.*sin(t), t.*cos(t), t);
save_fig(h_fig);

% === 3. Mesh Complex (din imaginea cu singularitate) ===
h_fig = figure(3);
x = [-10:0.1:10];
y = [-10:0.1:10];
[x, y] = meshgrid(x, y);
z = (x.^2 + y.^2 + 2*x - 3*y) ./ (x + y);
mesh(x, y, z);
save_fig(h_fig);

% === 4. Mesh Simplu (din imaginea cu meshgrid si mesh) ===
h_fig = figure(4);
[x y] = meshgrid(-2:0.2:2, -2:0.2:2);
z = x .* exp(-x.^2 - y.^2);
mesh(x,y,z);
save_fig(h_fig);

% === 5. Sombrero (din imaginea cu sombrero) ===
h_fig = figure(5);
sombrero(4);
save_fig(h_fig);

h_fig = figure(6);
sombrero(100);
save_fig(h_fig);

h_fig = figure(7);
[x y] = meshgrid(-2:0.2:2, -2:0.2:2);
z = x .* exp(-x.^2 - y.^2);
surf(x,y,z);
save_fig(h_fig);

h_fig = figure(8);
[x y] = meshgrid(-2:0.2:2, -2:0.2:2);
z = x .* exp(-x.^2 - y.^2);
surfc(x,y,z);
save_fig(h_fig);

h_fig = figure(9);
clf;
x0 = linspace(-3, 3, 51);
y0 = x0;
[x, y] = meshgrid(x0, y0);
f = sqrt(abs(x.*y)) ./ (1 + x.^2 + y.^2);
surf(x, y, f);
save_fig(h_fig);

h_fig = figure(10);
x = -3:0.125:3;
y = x;
[x y] = meshgrid(x,y);
z = peaks(x,y);
contour3(x,y,z,20);
save_fig(h_fig);

h_fig = figure(11);
[x, y] = meshgrid(-2:0.2:2, -2:0.2:3);
z = x .* exp(-x.^2 - y.^2);
contour(-2:0.2:2, -2:0.2:3, z, 8);
save_fig(h_fig);

h_fig = figure(5);
peaks(10);
save_fig(h_fig);

h_fig = figure(6);
peaks(51);
save_fig(h_fig);

h_fig = figure(5);
sphere(4);
save_fig(h_fig);

h_fig = figure(6);
sphere(10);
save_fig(h_fig);


h_fig = figure(12);
u = linspace(0, pi, 100);
v = linspace(0, 2*pi, 100);
[u, v] = meshgrid(u, v);
x = sin(u) .* cos(v);
y = sin(u) .* sin(v);
z = cos(u);
mesh(x, y, z);
save_fig(h_fig);

h_fig = figure(13);
sphere(50);
colormap hot;
axis equal;
save_fig(h_fig);

h_fig = figure(14);
r = 5;
[x, y, z] = sphere;
surf(r*x, r*y, r*z);
axis square;
colormap bone;
save_fig(h_fig);


h_fig = figure(15);
x0 = linspace(-3, 3, 51);
y0 = x0;
[x, y] = meshgrid(x0, y0);
z = 3*(1-x).^2.*exp(-(x.^2) - (y+1).^2) - 10*(x/5 - x.^3 - y.^5).*exp(-x.^2-y.^2) - 1/3*exp(-(x+1).^2 - y.^2);
surf(x, y, z);
colormap jet;
xlabel('x'); ylabel('y'); zlabel('z'); title('Peaks');
colormap cool;
shading interp;
save_fig(h_fig);

h_fig = figure(16);
[x y] = meshgrid(-2:0.2:2, -2:0.2:2);
z = x.*exp(-x.^2-y.^2);

subplot(221); mesh(x,y,z);
hold on;
subplot(222); meshz(x,y,z);
subplot(223); surf(x,y,z);
subplot(224); surfc(x,y,z);
hold off;
save_fig(h_fig);

h_fig = figure(17);
x = [2 3 4 8 7];
y = [1 2 3 4 3];
z = [4 1 2 0 3];
fill3(x, y, z, 'r');
save_fig(h_fig);

h_fig = figure(18);
x = [0.1 0.4 0.2 0.3];
explode = [0 1 0 0];
pie3(x, explode);
save_fig(h_fig);

h_fig = figure(19);
r = 3;
h = 5;
[x, y, z] = cylinder([r r], 5);
surf(x, y, h*z);
axis square;
colormap summer;
save_fig(h_fig);
