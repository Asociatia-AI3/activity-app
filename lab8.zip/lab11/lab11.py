import matplotlib.pyplot as plt
from mpl_toolkits import mplot3d
import numpy as np
import os

output_dir = "tema"
fig_counter = 1
def get_next_fig_counter():
    global fig_counter
    current = fig_counter
    fig_counter += 1
    return current

def save_fig(fig):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    counter = get_next_fig_counter()
    name = f"fig{counter}_3d.png"
    if name in os.listdir(output_dir):
        print(f"Fig {name} already exists!")
    else:
        fig.savefig(os.path.join(output_dir, name))
    
    
"""
fig = plt.figure()
ax = fig.add_subplot(projection='3d')
save_fig(fig)

fig = plt.figure()
ax = plt.axes(projection='3d')
save_fig(fig)

ax = plt.figure().add_subplot(projection='3d')
t = np.arange(0, 10*np.pi, np.pi/50)
ax.plot(np.sin(t), np.cos(t), t)
save_fig(ax.figure)

fig = plt.figure()
ax = plt.axes(projection='3d')
t = np.arange(0, 10*np.pi, np.pi/50)
ax.plot3D(np.sin(t), np.cos(t), t, 'magenta')
ax.set_title('3D Arc Function')
save_fig(fig)

fig = plt.figure(figsize=(3, 3))
ax = plt.axes(projection='3d')
x = np.arange(-2, 2, 0.2)
y = np.arange(-2, 3, 0.2)
x, y = np.meshgrid(x, y)
z = x * np.exp(-x**2 - y**2)
ax.plot_surface(x, y, z, cmap='hsv', edgecolor='none', alpha=1)
save_fig(fig)

fig = plt.figure(figsize=(3, 3))
ax = plt.axes(projection='3d')
t = np.linspace(0, 1, 150)
x = t * np.sin(20 * t)
y = t * np.cos(20 * t)
z = t
ax.scatter(x, y, z, c='deeppink')
save_fig(fig)

ax = plt.figure().add_subplot(projection='3d')
t = np.arange(0, 10*np.pi, 3)
ax.plot(np.sin(t), np.cos(t), t, 'orange')
save_fig(ax.figure)

fig = plt.figure(figsize=(3, 3))
ax = plt.axes(projection='3d')
x = np.arange(-2, 2, 0.2)
y = np.arange(-2, 3, 0.2)
x, y = np.meshgrid(x, y)
z = x * np.exp(-x**2 - y**2)
ax.contour(x, y, z, 8)
save_fig(fig)

ax = plt.figure().add_subplot(projection='3d')
t = np.arange(0, 10*np.pi, 1)
ax.plot(np.sin(t), np.cos(t), t, 'orange')
save_fig(ax.figure)

fig = plt.figure(figsize=(3, 3))
ax = plt.axes(projection='3d')
x = np.arange(-2, 2, 0.2)
y = np.arange(-2, 3, 0.2)
x, y = np.meshgrid(x, y)
z = x * np.exp(-x**2 - y**2)
ax.plot_wireframe(x, y, z, color='darkviolet')
save_fig(fig)

fig = plt.figure(figsize=(3, 3))
ax = plt.axes(projection='3d')
x = np.arange(-2, 2, 0.2)
y = np.arange(-2, 3, 0.2)
x, y = np.meshgrid(x, y)
z = x * np.exp(-x**2 - y**2)
ax.plot_surface(x, y, z, cmap='hsv', edgecolor='grey', alpha=0.4)
save_fig(fig)

ax = plt.figure().add_subplot(projection='3d')
t = np.arange(0, 10*np.pi, 0.1)
ax.plot(np.sin(t), np.cos(t), t, 'orange')
save_fig(ax.figure)

fig = plt.figure(figsize=(1, 1))
ax = fig.add_subplot(projection='3d')
t = np.arange(0, 10*np.pi, np.pi/50)
ax.plot(np.sin(t), np.cos(t), t)
save_fig(fig)

u = np.linspace(0, 2*np.pi, 100)
v = np.linspace(-1, 1, 100)
u, v = np.meshgrid(u, v)
x = (2 + v * np.cos(u/2)) * np.cos(u)
y = (2 + v * np.cos(u/2)) * np.sin(u)
z = v * np.sin(u/2)
fig = plt.figure(figsize=(5, 5))
ax = plt.axes(projection='3d')
ax.plot_surface(x, y, z, linewidth=0.2, cmap='cool', edgecolors='brown', alpha=0.5)
save_fig(fig)

x = np.linspace(-3, 3, 100)
y = np.linspace(-3, 3, 100)
x, y = np.meshgrid(x, y)
z = 2*(1-x**2)*np.exp(-x**2-(y+1)**2)-10*(x/5-x**3-y**5)*np.exp(-x**2-y**2)-(1/3)*np.exp(-(x+1)**2-y**2)
fig = plt.figure(figsize=(5, 5))
ax = plt.axes(projection='3d')
ax.plot_surface(x, y, z, cmap='bone')
save_fig(fig)

x = np.arange(-2, 2, 0.2)
y = np.arange(-2, 3, 0.2)
x, y = np.meshgrid(x, y)
z = x * np.exp(-x**2 - y**2)
fig = plt.figure(figsize=(3, 3))
ax = plt.axes(projection='3d')
ax.plot_surface(x, y, z, cmap='hsv', edgecolor='grey', alpha=0.4)
save_fig(fig)

import sys
x = np.linspace(-10, 10, 50)
y = np.linspace(-10, 10, 50)
x, y = np.meshgrid(x, y)
z = (x**2 + y**2 + 2*x - 3*y) / (x + y + sys.float_info.epsilon)
fig = plt.figure(figsize=(3, 3))
ax = plt.axes(projection='3d')
ax.plot_surface(x, y, z, linewidth=0.2, cmap='viridis', edgecolors='none', alpha=0.5)
save_fig(fig)

x = np.linspace(-10, 10, 100)
y = np.linspace(-10, 10, 100)
x, y = np.meshgrid(x, y)
z = np.sin(np.sqrt(x**2+y**2)) / np.sqrt(x**2+y**2)
fig = plt.figure(figsize=(5, 5))
ax = plt.axes(projection='3d')
ax.plot_surface(x, y, z, cmap='seismic')
save_fig(fig)

fig = plt.figure(figsize=(3, 3))
ax = plt.axes(projection='3d')
t = np.linspace(0, 1, 150)
x = t * np.sin(20*t)
y = t * np.cos(20*t)
z = t
ax.scatter(x, y, z, c='deeppink')
save_fig(fig)

x = np.arange(-2, 2, 0.2)
y = np.arange(-2, 3, 0.2)
x, y = np.meshgrid(x, y)
z = x * np.exp(-x**2 - y**2)
fig = plt.figure(figsize=(3, 3))
ax = plt.axes(projection='3d')
ax.plot_surface(x, y, z, cmap='hsv', edgecolor='none', alpha=1)
save_fig(fig)

x = np.arange(-2, 2, 0.2)
y = np.arange(-2, 3, 0.2)
x, y = np.meshgrid(x, y)
z = x * np.exp(-x**2 - y**2)
fig = plt.figure(figsize=(3, 3))
ax = plt.axes(projection='3d')
ax.contour(x, y, z, 8)
save_fig(fig)

x = np.linspace(-3, 3, 10)
y = np.linspace(-3, 3, 10)
x, y = np.meshgrid(x, y)
z = 2*(1-x**2)*np.exp(-x**2-(y+1)**2)-10*(x/5-x**3-y**5)*np.exp(-x**2-y**2)-(1/3)*np.exp(-(x+1)**2-y**2)
fig = plt.figure(figsize=(5, 5))
ax = plt.axes(projection='3d')
ax.plot_surface(x, y, z, cmap='bone')
save_fig(fig)

x = np.arange(-10, 10, 0.1)
y = np.arange(-10, 10, 0.1)
x, y = np.meshgrid(x, y)
z = np.sin(np.sqrt(x**2+y**2))
fig = plt.figure(figsize=(3, 3))
ax = plt.axes(projection='3d')
ax.plot_surface(x, y, z, cmap='hot')
save_fig(fig)

x = np.linspace(-3, 3, 50)
y = x
x, y = np.meshgrid(x, y)
z = np.sqrt(np.abs(x*y)) / (1 + x**2 + y**2)
fig = plt.figure(figsize=(3, 3))
ax = plt.axes(projection='3d')
ax.plot_surface(x, y, z, cmap='cubehelix', edgecolors='none', alpha=0.8)
save_fig(fig)

x = np.linspace(-10, 10, 14)
y = np.linspace(-10, 10, 14)
x, y = np.meshgrid(x, y)
z = np.sin(np.sqrt(x**2+y**2)) / np.sqrt(x**2+y**2)
fig = plt.figure(figsize=(5, 5))
ax = plt.axes(projection='3d')
ax.plot_surface(x, y, z, cmap='hot', alpha=0.7)
save_fig(fig)

alpha = np.linspace(0, 2*np.pi, 100)
beta = np.linspace(0, np.pi, 50)
alpha, beta = np.meshgrid(alpha, beta)
r = 1
x = r * np.sin(alpha) * np.cos(beta)
y = r * np.sin(alpha) * np.sin(beta)
z = r * np.cos(alpha)
fig = plt.figure(figsize=(4, 4))
ax = plt.axes(projection='3d')
ax.plot_surface(x, y, z, cmap='viridis', alpha=0.8)
ax.set_box_aspect((1, 1, 1))
save_fig(fig)

x = np.arange(-2, 2, 0.2)
y = np.arange(-2, 3, 0.2)
x, y = np.meshgrid(x, y)
z = x * np.exp(-x**2 - y**2)
fig = plt.figure(figsize=(3, 3))
ax = plt.axes(projection='3d')
ax.plot_wireframe(x, y, z, color='darkviolet')
save_fig(fig)

h = 5
r = 1
alpha = np.linspace(0, 2*np.pi, 7)
z = np.linspace(0, h, 10)
alpha, z = np.meshgrid(alpha, z)
x = r * np.cos(alpha)
y = r * np.sin(alpha)

fig = plt.figure(figsize=(3, 3))
ax = plt.axes(projection='3d')
ax.plot_surface(x, y, z, cmap='jet', edgecolor='none', alpha=0.9)
save_fig(fig)

h = 5
r = 1
alpha = np.linspace(0, 2*np.pi, 100)
z = np.linspace(0, h, 100)
alpha, z = np.meshgrid(alpha, z)
x = r * np.cos(alpha)
y = r * np.sin(alpha)

fig = plt.figure(figsize=(3, 3))
ax = plt.axes(projection='3d')
ax.plot_surface(x, y, z, cmap='jet', edgecolor='none', alpha=1)
save_fig(fig)

r1 = 1
r2 = 0.5
h = 3.0
theta = np.linspace(0, 2*np.pi, 100)
z = np.linspace(0, h, 100)
theta, z = np.meshgrid(theta, z)
r = r1 + (r2 - r1) * (z / h)
x = r * np.cos(theta)
y = r * np.sin(theta)

fig = plt.figure(figsize=(4, 4))
ax = plt.axes(projection='3d')
ax.plot_surface(x, y, z, cmap='coolwarm')
save_fig(fig)

r1 = 0.5
r2 = 0
h = 3.0
theta = np.linspace(0, 2*np.pi, 100)
z = np.linspace(0, h, 100)
theta, z = np.meshgrid(theta, z)
r = r1 + (r2 - r1) * (z / h)
x = r * np.cos(theta)
y = r * np.sin(theta)

fig = plt.figure(figsize=(4, 4))
ax = plt.axes(projection='3d')
ax.plot_surface(x, y, z, cmap='coolwarm')
save_fig(fig)

fig = plt.figure(figsize=(8, 8))

x = np.linspace(-10, 10, 50)
y = np.linspace(-10, 10, 50)
x, y = np.meshgrid(x, y)
z = (x**2 + y**2 + 2*x - 3*y) / (x + y + sys.float_info.epsilon)
ax = fig.add_subplot(2, 2, 1, projection='3d')
ax.plot_surface(x, y, z, cmap='coolwarm')

r1 = 1
r2 = 0.5
h = 3.0
theta = np.linspace(0, 2*np.pi, 100)
z = np.linspace(0, h, 100)
theta, z = np.meshgrid(theta, z)
r = r1 + (r2 - r1) * (z / h)
x_c = r * np.cos(theta)
y_c = r * np.sin(theta)
ax = fig.add_subplot(2, 2, 2, projection='3d')
ax.plot_surface(x_c, y_c, z, cmap='coolwarm')

x = np.linspace(-10, 10, 50)
y = x
x, y = np.meshgrid(x, y)
z = np.sqrt(np.abs(x*y)) / (1 + x**2 + y**2)
ax = fig.add_subplot(2, 2, 3, projection='3d')
ax.plot_surface(x, y, z, cmap='cubehelix', edgecolors='none', alpha=0.8)

r1 = 0.5
r2 = 0
theta = np.linspace(0, 2*np.pi, 100)
z = np.linspace(0, h, 100)
theta, z = np.meshgrid(theta, z)
r = r1 + (r2 - r1) * (z / h)
x_c = r * np.cos(theta)
y_c = r * np.sin(theta)
ax = fig.add_subplot(2, 2, 4, projection='3d')
ax.plot_surface(x_c, y_c, z, cmap='cubehelix', edgecolors='none', alpha=0.8)
save_fig(fig)

alpha = np.linspace(0, 2*np.pi, 10)
beta = np.linspace(0, np.pi, 5)
alpha, beta = np.meshgrid(alpha, beta)
r = 1
x = r * np.sin(alpha) * np.cos(beta)
y = r * np.sin(alpha) * np.sin(beta)
z = r * np.cos(alpha)

fig = plt.figure(figsize=(4, 4))
ax = plt.axes(projection='3d')
ax.plot_surface(x, y, z, cmap='copper', edgecolor='brown', alpha=0.8)
ax.set_box_aspect((1, 1, 1))
save_fig(fig)
"""


# Figura 1: Două curbe date numeric (2D)
x = np.linspace(0, 10, 20)
y1 = x**2
y2 = 2*x + 1
fig = plt.figure()
plt.plot(x, y1, label="y = x^2")
plt.plot(x, y2, label="y = 2x + 1")
plt.xlabel("x")
plt.ylabel("y")
plt.title("Două curbe date numeric")
plt.grid(True)
plt.legend()
save_fig(fig)

# Figura 2: Suprafața z = sin( sqrt(x^2 + y^2) ) (3D)
x = np.linspace(-3, 3, 50)
y = np.linspace(-3, 3, 50)
X, Y = np.meshgrid(x, y)
Z = np.sin(np.sqrt(X**2 + Y**2))
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.plot_surface(X, Y, Z, cmap='viridis')
ax.set_xlabel("x")
ax.set_ylabel("y")
ax.set_zlabel("z")
ax.set_title("Suprafața z = sin( sqrt(x^2 + y^2) )")
save_fig(fig)

# Exercițiul 1 – Grafic 2D cu două curbe
# t = 0:0.2:10, y1 = sin(t), y2 = exp(-0.3t)*sin(2t)
t = np.arange(0, 10.2, 0.2)
y1 = np.sin(t)
y2 = np.exp(-0.3 * t) * np.sin(2 * t)

fig = plt.figure()
plt.plot(t, y1, label='y1 = sin(t)')
plt.plot(t, y2, label='y2 = e^(-0.3t) * sin(2t)')
plt.title('Exercițiul 1: Grafic 2D cu două curbe')
plt.xlabel('t')
plt.ylabel('Valori')
plt.legend()
plt.grid(True)
save_fig(fig)

# Exercițiul 2 – Două funcții pe același grafic (Markere diferite)
# x = 1:15, y1 = ln(x), y2 = sqrt(x)
x = np.arange(1, 16) # De la 1 la 15
y1 = np.log(x)
y2 = np.sqrt(x)

fig = plt.figure()
plt.plot(x, y1, 'r-o', label='ln(x)')
plt.plot(x, y2, 'b--s', label='sqrt(x)')
plt.title('Exercițiul 2: Două funcții cu markere diferite')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.grid(True)
save_fig(fig)

# Exercițiul 3 – Grafic cu puncte + linie
# x = linspace(-5,5,25), y = x^3 - 3x
x_scatter = np.linspace(-5, 5, 25)
y_scatter = x_scatter**3 - 3*x_scatter

x_line = np.linspace(-5, 5, 100)
y_line = x_line**3 - 3*x_line

fig = plt.figure()
plt.scatter(x_scatter, y_scatter, color='red', label='Puncte discrete', zorder=5)
plt.plot(x_line, y_line, color='blue', label='Linie netedă (funcția)')
plt.title('Exercițiul 3: Scatter + Linie')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.grid(True)
save_fig(fig)

# Exercițiul 4 – Suprafață 3D
# z = cos(x) * sin(y), x,y = linspace(-4,4,60)
x = np.linspace(-4, 4, 60)
y = np.linspace(-4, 4, 60)
X, Y = np.meshgrid(x, y)
Z = np.cos(X) * np.sin(Y)

fig = plt.figure()
ax = fig.add_subplot(projection='3d')
ax.plot_surface(X, Y, Z, cmap='coolwarm')
ax.set_title('Exercițiul 4: Suprafață 3D cos(x)sin(y)')
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_zlabel('z')
save_fig(fig)

# Exercițiul 5 – Suprafață „pălărie mexicană”
# z = sin(sqrt(x^2+y^2)) / sqrt(x^2+y^2)
x = np.linspace(-6, 6, 80)
y = np.linspace(-6, 6, 80)
X, Y = np.meshgrid(x, y)
R = np.sqrt(X**2 + Y**2)
Z = np.sin(R) / (R + 1e-9) 

fig = plt.figure()
ax = fig.add_subplot(projection='3d')
ax.plot_surface(X, Y, Z, cmap='plasma', linewidth=0, antialiased=False)
ax.set_title('Exercițiul 5: Pălărie mexicană')
save_fig(fig)

# Exercițiul 6 – Suprafață parametrică
# x = u*cos(v), y = u*sin(v), z = u^2 - v
u = np.linspace(0, 3, 50)
v = np.linspace(0, 2*np.pi, 50)
U, V = np.meshgrid(u, v)

X = U * np.cos(V)
Y = U * np.sin(V)
Z = U**2 - V

fig = plt.figure()
ax = fig.add_subplot(projection='3d')
ax.plot_surface(X, Y, Z, cmap='inferno')
ax.set_title('Exercițiul 6: Suprafață parametrică')
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_zlabel('z')
save_fig(fig)