import os
from sympy import symbols, cos, sin, exp, pi, sqrt, And, Eq, I, re, atan
from sympy.plotting import plot, plot3d, plot_implicit, plot_parametric, plot3d_parametric_line, plot3d_parametric_surface, PlotGrid
import matplotlib.cm as cm

output_dir = "figuri"
fig_counter = 1

if not os.path.exists(output_dir):
    os.makedirs(output_dir)

def get_next_fig_counter():
    global fig_counter
    current = fig_counter
    fig_counter += 1
    return current

def save_fig(p):
    counter = get_next_fig_counter()
    name = f"fig{counter}_3d.png"
    if name in os.listdir(output_dir):
        print(f"Fig {name} already exists!")
    else:
        p.save(os.path.join(output_dir, name))

x, y = symbols('x y')

p = plot(x**2 + x + 1, size=(2, 2), show=False)
save_fig(p)

p = plot(x**2 + x + 1, (x, -1, 1), line_color='darkred', size=(2, 2), show=False)
save_fig(p)

p = plot(x**2 + x + 1, xlim=(-2, 2), ylim=(-2, 2), line_color='pink', size=(3, 3), show=False)
save_fig(p)

p = plot((cos(x), (x, -pi, pi)), (sin(x), (x, -pi, pi)), (exp(x) - 1, (x, -2, 2)), size=(3, 3), show=False)
save_fig(p)

p = plot(cos(x), sin(x), exp(x) - 1, (x, -pi/2, pi/2), size=(3, 3), show=False)
save_fig(p)

p1 = plot(sin(x), show=False, size=(2, 2))
p2 = plot(x, show=False)
p1.append(p2[0])
save_fig(p1)

p1 = plot(sin(x), show=False, size=(2, 2))
p2 = plot(x/2, -x/2, show=False)
p1.extend(p2)
save_fig(p1)

p = plot_implicit(x**2 + y**2 - 10, size=(3, 3), show=False)
save_fig(p)

p = plot_implicit(Eq(x**2 + y**2, 10), show=False)
save_fig(p)

p = plot_implicit(x**2 + y**2 - 10, (x, -7, 7), (y, -7, 7), show=False)
save_fig(p)

p = plot_implicit(x**2 + y**2 - 10, (x, -7, 7), (y, -2, 2), size=(3, 3), show=False)
save_fig(p)

p = plot_implicit(And(y > cos(x), y < sin(x)), line_color='orange', size=(2, 2), show=False)
save_fig(p)

p = plot_implicit(y > x**3 + 3, size=(3, 3), show=False)
save_fig(p)

t = symbols('t')
p = plot_parametric((sqrt(10)*cos(t), sqrt(10)*sin(t)), size=(2, 2), show=False)
save_fig(p)

u = symbols('u')
p = plot_parametric((cos(u), sin(u), (u, -7, 7)), (cos(u), exp(u), (u, -2, 2)), size=(2, 2), show=False)
save_fig(p)

p = plot3d_parametric_line((sin(t), cos(t), t), (t, -25, 25), size=(2, 2), show=False)
save_fig(p)

p = plot3d_parametric_line((sin(t), cos(t), t, (t, -8, 8)), (cos(2*t), sin(2*t), 2*t, (t, -8, 8)), line_color='red', show=False, size=(2, 2))
p[0].line_color = 'green'
save_fig(p)

p = plot3d(x*exp(-x**2 - y**2), (x, -2, 2), (y, -2, 2), size=(3, 3), show=False)
save_fig(p)

p = plot3d(x*exp(-x**2 - y**2), -x**2 - y**2, (x, -20, 20), (y, -20, 20), surface_color=('yellow', 'green'), show=False, size=(3, 3))
p[0].surface_color = ('red', 'blue')
save_fig(p)

p = plot3d(re(atan(x + I*y)), (x, -25, 25), (y, -25, 25), size=(3, 3), show=False)
save_fig(p)

p = plot3d(sin(x)*sin(y), (x,-2*pi, 2*pi), (y, -2*pi, 2*pi), size=(3, 3), show=False)
save_fig(p)

p = plot3d((1/(2*pi))*exp(-1/2)*(x**2+y**2), (x, -2*pi, 2*pi), (y, -2*pi, 2*pi), size=(3, 3), show=False)
save_fig(p)

p = plot3d((1/(2*pi))*exp(-1/2)*(x**2+y**2), (x, -1, 1), (y, -1, 1), size=(3, 3), show=False)
save_fig(p)

u,v = symbols('u v')
p = plot3d_parametric_surface(sin(u)*cos(v), sin(u)*sin(v), u*sin(v), size=(3, 3), show=False)
save_fig(p)

p = plot3d_parametric_surface(u*sin(v), -u*cos(v), v, size=(3, 3), show=False)
save_fig(p)

p1 = plot(x**2-1, line_color='red', show=False)
p2 = plot_parametric(cos(x), exp(x), line_color='yellow', show=False)
p3 = plot_implicit(x**2-y**2-10, line_color='blue', show=False)
p4 = plot3d_parametric_line(sin(x), cos(x), x, line_color='green', show=False)
p5 = plot3d(sin(x)*sin(y), show=False)
p6 = plot3d_parametric_surface(x*sin(y), -x*cos(y), y, show=False)

p = PlotGrid(2, 3, p1, p2, p3, p4, p5, p6, show=False)
save_fig(p)

p1_b = plot3d(cos(x**2 + y**2), (x, -2, 2), (y, -2, 2), show=False)
p2_b = plot3d(cos(x**2 + y**2), (x, -2, 2), (y, -2, 2), dict(cmap=cm.coolwarm), show=False)
p3_b = plot3d(cos(x**2 + y**2), (x, -2, 2), (y, -2, 2), dict(cmap=cm.jet), show=False)

p = PlotGrid(1, 3, p1_b, p2_b, p3_b, size=(7, 7), show=False)
save_fig(p)

p1 = plot3d(cos(x**2 + y**2), show=False)
p2 = plot3d(cos(x**2 + y**2), dict(cmap=cm.coolwarm), show=False)
p3 = plot3d(cos(x**2 + y**2), dict(cmap=cm.jet), show=False)

p = PlotGrid(1, 3, p1, p2, p3, size=(7, 7), show=False)
save_fig(p)

p = plot3d_parametric_surface(
    cos(x + y), 
    sin(x - y), 
    x - y, 
    (x, -9, 9), 
    (y, -9, 9), 
    dict(cmap=cm.jet), 
    size=(3, 3), 
    show=False
)
save_fig(p)

p1 = plot3d_parametric_surface(x*sin(y), -x*cos(y), y, dict(cmap=cm.jet), size=(3, 3), show=False)
save_fig(p1)

p2 = plot3d(sin(x)*sin(y), dict(cmap=cm.hot), size=(3, 3), show=False)
save_fig(p2)

p3 = plot3d_parametric_surface(sin(x)*cos(y), sin(x)*sin(y), x*sin(y), dict(cmap=cm.hsv), size=(3, 3), show=False)
save_fig(p3)

p4 = plot3d(x*exp(-x**2 - y**2), (x, -2, 2), (y, -2, 2), dict(cmap=cm.hsv), size=(3, 3), show=False)
save_fig(p4)

p1 = plot(cos(x), sin(x), show=False)
p2 = plot((cos(x), dict(color="green")), (sin(x), dict(linestyle="-.", linewidth=3)), show=False)

pg = PlotGrid(1, 2, p1, p2, size=(7, 3), show=False)
save_fig(pg)