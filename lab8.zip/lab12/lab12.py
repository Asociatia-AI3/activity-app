# 14, 15, 17, 18, 19, 20, 21, 63, 64
import numpy as np
import sympy as sp
from sympy import sin, cos, sqrt, lambdify, sympify
import math

a=np.sqrt(27)
print(a)
b=sp.sqrt(27)
print(b)

a=np.sqrt(2)
print(a)
1+a
print(a)
b=sp.sqrt(2)
print(b)
1+b
print(b)

x, y = sp.symbols('x y')
expr = x-7*y**2
print(expr)
print(expr-x)

x, y = sp.symbols('x y')
expr = x-7*y**2
print(x**3*expr)

x, z = sp.symbols('x z')
expr = cos(x) + sin(x) + x
expr = expr.subs(x, z)
print(expr)

expr = cos(x) + sin(x) + x
expr = expr.subs(x, 0)
print(expr)

expr = cos(x)
a = expr.subs(x, 0)
print(a)
print(expr)

expr = cos(x)
a = expr.subs(x, z)
print(a)
print(expr)

expr = x**2 + 2*x*y - y**3
print(expr.subs([(x, 2), (y, 4)]))

expr = sqrt(27)
print(expr)
a=expr.evalf()
print(a)
a_2=expr.evalf(2)
print(a_2)

a = np.arange(4)
expr = sin(x)
f = lambdify(x, expr, modules=['numpy'])
print(f(a))

print(1+sqrt(2))

s='x**2-7*x'
print(s)
print(sympify(s))
print(sympify(s)-x)

