"""
1. Reprezentați grafic, într-o figură cu 3 subferestre:
a) Curba:
𝑥 = 𝑡, 𝑦 = 𝑡
2
, 𝑧 = 𝑡
3
,𝑡 ∈ [−2,2]
b) Suprafața:
𝑧 = √𝑥
2 + 𝑦
2, 𝑥, 𝑦 ∈ [−4,4]
c) Suprafața parametrică:
{
𝑥 = 𝑡cos (𝑠)
𝑦 = 𝑡sin (𝑠)
𝑧 = 𝑡
,𝑡 ∈ [0,3], s∈[0,2π]
2. Reprezentați grafic într-o figură cu 3 subferestre:
a) Curba parametrică:
𝑥(𝑡) = 𝑡cos (𝑡), 𝑦(𝑡) = 𝑡sin (𝑡), 𝑧(𝑡) = 𝑡,𝑡 ∈ [0,6𝜋]
b) Suprafața:
𝑧 = 𝑥
2 − 𝑦
2
, 𝑥, 𝑦 ∈ [−3,3]
c) Suprafața parametrică:
{
𝑥(𝑡, 𝑠) = 𝑡
𝑦(𝑡, 𝑠) = 𝑠
𝑧(𝑡, 𝑠) = 𝑡
2 + 𝑠
2
,𝑡, 𝑠 ∈ [−2,2]
"""

import sympy as sp
import numpy as np
import matplotlib.pyplot as plt
# 1. Variabile simbolice
t, s, x, y = sp.symbols('t s x y')
# 2. Expresii simbolicе
# a) Curba 3D parametrică
x_t = sp.cos(t)
y_t = sp.sin(t)
z_t = t
# b) Suprafața explicită z = f(x,y)
f_xy = sp.sin(sp.sqrt(x**2 + y**2))
# c) Suprafața parametrică
x_ts = sp.cos(t) * sp.sin(s)
y_ts = sp.sin(t) * sp.sin(s)
z_ts = sp.cos(s)
# 3. Domenii
t_vals = np.linspace(0, 4*np.pi, 400)
x_vals = np.linspace(-5, 5, 100)
y_vals = np.linspace(-5, 5, 100)
X, Y= np.meshgrid(x_vals, y_vals)
t_vals_p = np.linspace(0, 2*np.pi, 80)
s_vals_p = np.linspace(0, np.pi, 80)
T, S = np.meshgrid(t_vals_p, s_vals_p)
# 4. Conversie simbolic -> numeric
fx = sp.lambdify(t, x_t, 'numpy')
fy = sp.lambdify(t, y_t, 'numpy')
fz = sp.lambdify(t, z_t, 'numpy')
Xc = fx(t_vals)
Yc = fy(t_vals)
Zc = fz(t_vals)
f_num = sp.lambdify((x, y), f_xy, 'numpy')
Z = f_num(X, Y)
fxp = sp.lambdify((t, s), x_ts, 'numpy')
fyp = sp.lambdify((t, s), y_ts, 'numpy')
fzp = sp.lambdify((t, s), z_ts, 'numpy')
Xp = fxp(T, S)
Yp = fyp(T, S)
Zp = fzp(T, S)
# 5. Reprezentare grafica
fig = plt.figure(figsize=(15, 5))
ax1 = fig.add_subplot(131, projection='3d')
ax1.plot(Xc, Yc, Zc)
ax1.set_title('Curba 3D parametrică')
ax2 = fig.add_subplot(132, projection='3d')
ax2.plot_surface(X, Y, Z, cmap='viridis')
ax2.set_title('Suprafața explicită z = f(x,y)')
ax3 = fig.add_subplot(133, projection='3d')
ax3.plot_surface(Xp, Yp, Zp, cmap='plasma')
ax3.set_title('Suprafața parametrică')
plt.tight_layout()
plt.show()
