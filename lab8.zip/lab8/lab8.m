% 1. Determina�0�4i �0�2i afi�0�2a�0�4i folosind vectorul x=[2 4 5 7 10]
%-Valoarea minim�0�0 a vectorului x
%-Valoarea maxim�0�0 a vectorului x
%-Suma elementelor vectorului
%-Produsul elementelor vectorului
%-Suma p�0�0tratelor elementelor

  %  Calcula�0�4i �0�2i afi�0�2a�0�4i vectorii:
%cumsum(x) �C suma cumulat�0�0 a elementelor
%cumprod(x) �C produsul cumulat al elementelor
 % Afi�0�2a�0�4i  toate rezultatele folosind comenzi precum
%fprintf, disp (�0�6n Octave) sau print (�0�6n Python).

%2.Calculul mediilor
%Media aritmetica
%Media geormetrica
%Media armonica
%Afisati cele trei tipuri de medii folosint fprintf(Octave) sau print(Python)

%3.Coeficientul de corelatie intre 2 seturi de date
%Construiti functia liniara f(x)=2x+3
%Calculati coeficientul de corelatie intre vectorul x si vectorul generat f(x)
%Folosind vectorii u=x si v=[1.3.4.6.9] calculati coeficiantul de corelatie corrcoef (u,v)
%Afisati rezultatele sub forma  corrcoef(x, f(x)) = ...   / corrcoef(u, v) =

%4.Aplicatie cu note(curs,laborator si nota finala)-   nota_curs = [7 8 9 6 10]   /   nota_lab = [8 8 7 9 10]
%Calculati nota finala pentru fiecare student folosind formula 0.6 nota curs +0.4 nota laborator si afisati vectorul rezultatelor
%Determina�0�4i coeficientul de corela�0�4ie dintre notele de la curs �0�2i notele de la laborator, folosind comanda: corrcoef(nota_curs, nota_lab)
%Interpreta�0�4i rezultatul corela�0�4iei:

%- dac�0�0 valoarea este aproape 1 �� notele au leg�0�0tur�0�0 puternic�0�0 (corelate pozitiv)
%- dac�0�0 este aprox. 0 �� nu exist�0�0 rela�0�4ie
%- dac�0�0 este aproape -1 �� corela�0�4ie negativ�0�0

%5.Sortare si generare de numere aleatoare
%Sorteaza vectorul x in ordine crescatoare folosind comanda sort(x, ascend)
%Sorteaz�0�0 vectorul x �0�6n ordine descresc�0�0toare folosind comanda: sort(x, descend)
%Genereaz�0�0 un vector de 5 numere aleatoare uniform distribuite �0�6n intervalul (0,1) folosind: rand(1,5)
%Genereaz�0�0 un vector de 5 numere �0�6ntregi aleatoare �0�6n intervalul [1,100] folosind: randi([1 100], 1, 5)
% Afiseaza toate rezultatele. """

clc; clear; close all;

% Vector de lucru (toate > 0 pentru mediile geo/armonice)
x = [2 4 5 7 10];

% 1) MIN, MAX, SUM, PROD, suma p�0�0tratelor, CUMSUM, CUMPROD
xmin = min(x);  xmax = max(x);
s   = sum(x);   p   = prod(x);
s2  = sum(x.^2);
cs  = cumsum(x);
cp  = cumprod(x);

fprintf("MIN=%g, MAX=%g, SUM=%g, PROD=%g, SUM(x.^2)=%g\n", xmin,xmax,s,p,s2);
disp("cumsum(x) ="), disp(cs)
disp("cumprod(x) ="), disp(cp)

% 2) Medii: aritmetic�0�0, geometric�0�0, armonic�0�0 (f�0�0r�0�0 toolbox)
mean_a = mean(x);
mean_g = exp(mean(log(x)));        % x>0
mean_h = numel(x) / sum(1./x);     % x>0
fprintf("Mean(A)=%g, Geo=%g, Harm=%g\n", mean_a, mean_g, mean_h);

% 3) Corela�0�4ie: corrcoef(f(x)) �0�2i corrcoef(u,v)
f = 2*x + 3;                       % func�0�4ie liniar�0�0
R1 = corrcoef(x, f);               % matrice 2x2 -> r este R1(1,2)
fprintf("corrcoef(x, f(x)) = %g\n", R1(1,2));

u = x;
v = [1 3 4 6 9];
R2 = corrcoef(u, v);
fprintf("corrcoef(u, v) = %g\n", R2(1,2));

% 4)Aplica�0�4ie note: curs/lab/medie final�0�0
nota_curs = [7 8 9 6 10];
nota_lab  = [8 8 7 9 10];
nota_finala = 0.6*nota_curs + 0.4*nota_lab;
disp("Note finale ="), disp(nota_finala)
Rnote = corrcoef(nota_curs, nota_lab);
fprintf("Corela�0�4ie curs-lab = %g\n", Rnote(1,2));

% 5) sort & random
v_sort_up   = sort(x, "ascend");
v_sort_down = sort(x, "descend");
disp("sort asc ="), disp(v_sort_up)
disp("sort desc ="), disp(v_sort_down)

r_uni  = rand(1,5);    % uniform(0,1)
r_int  = randi([1 100], 1, 5);
disp("rand(1,5) ="), disp(r_uni)
disp("randi([1 100],1,5) ="), disp(r_int)
