"""1. Determinați și afișați folosind vectorul x=[2 4 5 7 10] 
-Valoarea minimă a vectorului x 
-Valoarea maximă a vectorului x 
-Suma elementelor vectorului 
-Produsul elementelor vectorului 
-Suma pătratelor elementelor 

    Calculați și afișați vectorii: 
cumsum(x) – suma cumulată a elementelor 
cumprod(x) – produsul cumulat al elementelor 
  Afișați  toate rezultatele folosind comenzi precum 
fprintf, disp (în Octave) sau print (în Python). 

 

2.Calculul mediilor  
Media aritmetica 
Media geormetrica 
Media armonica 
Afisati cele trei tipuri de medii folosint fprintf(Octave) sau print(Python) 

3.Coeficientul de corelatie intre 2 seturi de date 
Construiti functia liniara f(x)=2x+3 
Calculati coeficientul de corelatie intre vectorul x si vectorul generat f(x) 
Folosind vectorii u=x si v=[1.3.4.6.9] calculati coeficiantul de corelatie corrcoef (u,v) 
Afisati rezultatele sub forma  corrcoef(x, f(x)) = ...   / corrcoef(u, v) = 

4.Aplicatie cu note(curs,laborator si nota finala)-   nota_curs = [7 8 9 6 10]   /   nota_lab = [8 8 7 9 10] 
Calculati nota finala pentru fiecare student folosind formula 0.6 nota curs +0.4 nota laborator si afisati vectorul rezultatelor 
Determinați coeficientul de corelație dintre notele de la curs și notele de la laborator, folosind comanda: corrcoef(nota_curs, nota_lab) 
Interpretați rezultatul corelației: 

- dacă valoarea este aproape 1 → notele au legătură puternică (corelate pozitiv) 
- dacă este aprox. 0 → nu există relație 
- dacă este aproape -1 → corelație negativă 

5.Sortare si generare de numere aleatoare 
Sorteaza vectorul x in ordine crescatoare folosind comanda sort(x, "ascend") 
Sortează vectorul x în ordine descrescătoare folosind comanda: sort(x, "descend") 
Generează un vector de 5 numere aleatoare uniform distribuite în intervalul (0,1) folosind: rand(1,5) 
Generează un vector de 5 numere întregi aleatoare în intervalul [1,100] folosind: randi([1 100], 1, 5) 
Afiseaza toate rezultatele. """
import numpy as np 
import pandas as pd
import scipy as sp

# Vector de lucru (toate > 0 pentru mediile geo/armonice) 
x = np.array([2, 4, 5, 7, 10], dtype=float) 

# 1) MIN, MAX, SUM, PROD, sum of squares, CUMSUM, CUMPROD 
xmin = np.min(x);  xmax = np.max(x) 
s    = np.sum(x);  p    = np.prod(x) 
s2   = np.sum(x**2) 
cs   = np.cumsum(x) 
cp   = np.cumprod(x) 

print(f"MIN={xmin}, MAX={xmax}, SUM={s}, PROD={p}, SUM(x**2)={s2}") 
print("cumsum(x) =", cs) 
print("cumprod(x) =", cp) 

# 2) Arithmetic / Geometric / Harmonic means (fără SciPy) 
mean_a = np.mean(x) 
mean_g = np.exp(np.mean(np.log(x)))      # x>0 
mean_h = len(x) / np.sum(1.0/x)          # x>0 
print(f"Mean(A)={mean_a}, Geo={mean_g}, Harm={mean_h}") 

# 3) Correlation: corrcoef(f(x)) și corrcoef(u, v) 
f = 2*x + 3 

r_xf = np.corrcoef(x, f)[0, 1] 
print("corrcoef(x, f(x)) =", r_xf) 

u = x 
v = np.array([1, 3, 4, 6, 9], dtype=float) 
r_uv = np.corrcoef(u, v)[0, 1] 
print("corrcoef(u, v) =", r_uv) 

# Aplicație note: curs/lab/medie finală 
nota_curs = np.array([7, 8, 9, 6, 10], dtype=float) 
nota_lab  = np.array([8, 8, 7, 9, 10], dtype=float) 
nota_finala = 0.6*nota_curs + 0.4*nota_lab 
print("Note finale =", nota_finala) 
r_note = np.corrcoef(nota_curs, nota_lab)[0, 1] 
print("Corelație curs-lab =", r_note) 

# 4) Corelație pe seturi de date Pandas 
#   Pandas = bibliotecă pentru tabele (DataFrame) – ca un Excel în memorie. 
df = pd.DataFrame({ 
    "curs": nota_curs, 
    "lab":  nota_lab, 
    "final": nota_finala 
}) 

# Matricea de corelații Pearson între toate coloanele: 
print("\nPandas DataFrame.corr():\n", df.corr(numeric_only=True)) 

# Corelație doar între două serii: 
print("Series.corr(curs, lab) =", df["curs"].corr(df["lab"])) 

# 5) sort & random 
x_sort_up   = np.sort(x) 
x_sort_down = np.sort(x)[::-1] 
print("sort asc =", x_sort_up) 
print("sort desc =", x_sort_down) 

np.random.seed(0) 
r_uni  = np.random.rand(5)          # uniform(0,1) 
r_int  = np.random.randint(1, 101, size=5) 
print("rand(5) =", r_uni) 
print("randint(1..100,5) =", r_int) 

# 7) Media geometrica si armonica cu SciPy
A = np.array([[2, 4, 5], [3, 7, 10], [1, 6, 8]], dtype=float)
mean_g_sp = sp.stats.gmean(A)
mean_g_sp_row = sp.stats.gmean(A, axis=1)
mean_g_sp_col = sp.stats.gmean(A, axis=0)

mean_h_sp = sp.stats.hmean(A)
mean_h_sp_row = sp.stats.hmean(A, axis=1)
mean_h_sp_col = sp.stats.hmean(A, axis=0)

print(f"SciPy Geometric Mean (all) = {mean_g_sp}")
print(f"SciPy Geometric Mean (row-wise) = {mean_g_sp_row}")
print(f"SciPy Geometric Mean (col-wise) = {mean_g_sp_col}")

print(f"SciPy Harmonic Mean (all) = {mean_h_sp}")
print(f"SciPy Harmonic Mean (row-wise) = {mean_h_sp_row}")
print(f"SciPy Harmonic Mean (col-wise) = {mean_h_sp_col}")

# calcularea mediei pe seturi de date Pandas
data = [['Alice', 25, 5.5],
        ['Bob', 30, 6.0],
        ['Charlie', 35, 5.8],
        ['David', 40, 6.2]]

df_people = pd.DataFrame(data, columns=['Name', 'Age', 'Height'])   
mean_age = df_people['Age'].mean()
mean_height = df_people['Height'].mean()
print(f"Mean Age = {mean_age}")
print(f"Mean Height = {mean_height}")