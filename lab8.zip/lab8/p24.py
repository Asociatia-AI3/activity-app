import numpy as np 
# y has 3 columns: 
# y[:,0] = number of study hours per day 
# y[:,1] = partial exam grade 
# y[:,2] = final grade 

y = np.array([ 
    [8, 10,  9], 
    [4,  6,  5], 
    [5,  6,  7], 
    [10, 10,  9], 
    [10,  9, 10], 
    [7,  9,  9], 
    [2,  5,  7], 
    [5,  7,  6], 
    [1,  4,  3], 
    [6,  8,  7] 
]) 

print("Matrix y (col1=hours, col2=partial, col3=final):") 
print(y) 

# Calculate correlation matrix 
R = np.corrcoef(y, rowvar=False) 

print("\nCorrelation matrix R = corrcoef(y):") 
print(R) 

# Interpretation notes (for lab explanation): 
print("\nInterpretation tips:") 
print("R[0,1] = correlation between study hours and partial exam grade") 
print("R[0,2] = correlation between study hours and final grade") 
print("R[1,2] = correlation between partial and final grade") 