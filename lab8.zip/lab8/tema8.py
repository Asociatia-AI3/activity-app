import numpy as np
import scipy as sp

"""1.Pentru vectorul x = [3 6 8 11 15],calculati:
a)Determinați și afișați următoarele folosind vectorul x: Valoarea minimă a vectorului x
Valoarea maximă a vectorului x Suma elementelor
Produsul elementelor
✔ Media elementelor
Suma pătratelor elementelor
b)Calculați și afișați vectorii:
✓
cumsum(x) - suma cumulată a elementelor
cumprod(x) – produsul cumulat al elementelor
C) Afișați rezultatele folosind fprintf, disp (Octave) sau print (Python)."""

x = np.array([3, 6, 8, 11, 15], dtype=float)
xmin = np.min(x);  xmax = np.max(x)
s    = np.sum(x);  p    = np.prod(x)
mean = np.mean(x)
s2   = np.sum(x**2)

cs   = np.cumsum(x)
cp   = np.cumprod(x)

print(f"MIN={xmin}, MAX={xmax}, SUM={s}, PROD={p}, MEAN={mean}, SUM(x**2)={s2}")
print("cumsum(x) =", cs)
print("cumprod(x) =", cp)

"""2. Folosind același vector x, calculați:
Media aritmetică
Media geometrică
Media armonică
Afişați cele trei tipuri de medii folosind fprintf (Octave) sau print (Python)."""

geo_mean = sp.stats.gmean(x)
harm_mean = sp.stats.hmean(x)
print(f"Media aritmetica: {mean}, Media geometrica: {geo_mean}, Media armonica: {harm_mean}")


"""3. Construiți funcţia liniară f(x) = 3x - 5
✓ Calculați coeficientul de corelaţie între vectorul x și vectorul generat f(x).
✓ Calculaţi coeficientul de corelație pentru vectorii: x = xv = |2,5,7,12,14]|| ✓ Afişați rezultatele sub forma:
corrcoef(x, f(x)) = ... corrcoef(u, v) = ..."""
f_x = 3 * x - 5
R1 = np.corrcoef(x, f_x)[0, 1]
u = x
v = np.array([2, 5, 7, 12, 14], dtype=float)
R2 = np.corrcoef(u, v)[0, 1]
print(f"corrcoef(x, f(x)) = {R1}")
print(f"corrcoef(u, v) = {R2}")


"""4.Se dau nota_curs = [6 9 7 8 10]; 
                 nota_lab  = [7 5 8 8 9]; 
 Calculați nota finală pentru fiecare student folosind formula:5% curs,5%lab 
Determinați coeficientul de corelație dintre notele de la curs și laborator. 
 Interpretați rezultatul corelației: 
aproape de 1 → corelație pozitivă puternică 
aproape de 0 → fără legătură 
aproape de –1 → corelație negativă """

nota_curs = np.array([6, 9, 7, 8, 10], dtype=float)
nota_lab  = np.array([7, 5, 8, 8, 9], dtype=float)
nota_finala = 0.5 * nota_curs + 0.5 * nota_lab
R3 = np.corrcoef(nota_curs, nota_lab)[0, 1]
print(f"Nota finala pentru fiecare student: {nota_finala}")
print(f"Coeficientul de corelație dintre notele de la curs și laborator: {R3}")

"""5.  Sortează vectorul x în: 
ordine crescătoare  
 ordine descrescătoare 
 Generează: 
un vector de 8 numere reale aleatoare în intervalul (0,1) 
un vector de 8 numere întregi aleatoare în intervalul [10, 50] 
Afișați toate rezultatele."""

x_sorted_asc = np.sort(x)
x_sorted_desc = np.sort(x)[::-1]
rand_real = np.random.rand(8)
rand_int = np.random.randint(10, 51, size=8)
print("Vector x sortat în ordine crescătoare:", x_sorted_asc)
print("Vector x sortat în ordine descrescătoare:", x_sorted_desc)
print("Vector de 8 numere reale aleatoare în intervalul (0,1):", rand_real)
print("Vector de 8 numere întregi aleatoare în intervalul [10, 50]:", rand_int)