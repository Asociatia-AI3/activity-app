clc; clear; close all;

%1. Folosind valoarea x = 5.7, calcula�0�4i �0�2i afi�0�2a�0�4i:
%a) r�0�0d�0�0cina p�0�0trat�0�0 din x: ��x
%b) exponen�0�4iala lui x: e�0�7
%c) logaritmul natural din x: ln(x)
%d) logaritmul zecimal din x: log�6�9�6�8(x)
%e) logaritmul �0�6n baza 2 din x: log�6�0(x)

%2.Folosind y = -3, calcula�0�4i �0�2i afi�0�2a�0�4i:
%a) modulul lui y: |y|
%b) semnul lui y,(�6�11 dac�0�0 e negativ, 0 dac�0�0 e 0, +1 dac�0�0 e pozitiv)

%3.Folosind a = 2 �0�2i b = 5, calcula�0�4i �0�2i afi�0�2a�0�4i:
%a) puterea lui a la b, adic�0�0:
%a^b=2^5

% Datele din enunt
x = 5.7;
y = -3;
a = 2;
b = 5;

% 1) Functii pe x
fprintf("=== 1) Functii matematice elementare pe x ===\n");

sqrt_x  = sqrt(x);   % radacina patrata
exp_x   = exp(x);    % exponentiala
ln_x    = log(x);    % logaritm natural (ln)
log10_x = log10(x);  % logaritm zecimal
log2_x  = log2(x);   % logaritm in baza 2

fprintf("x = %g\n", x);
fprintf("sqrt(x)   = %g\n", sqrt_x);
fprintf("exp(x)    = %g\n", exp_x);
fprintf("ln(x)     = %g\n", ln_x);
fprintf("log10(x)  = %g\n", log10_x);
fprintf("log2(x)   = %g\n\n", log2_x);

% 2) Modulul si semnul lui y
fprintf("=== 2) Modulul si semnul lui y ===\n");
abs_y  = abs(y);   % modulul
sign_y = sign(y);  % semnul: -1, 0, 1
fprintf("y = %g\n", y);
fprintf("|y| = %g\n", abs_y);
fprintf("sign(y) = %g\n\n", sign_y);

% 3) Puterea unui numar
fprintf("=== 3) Puterea unui numar ===\n");
a_pow_b = a^b;    % a la puterea b

fprintf("a = %g, b = %g\n", a, b);
fprintf("a^b = %g\n", a_pow_b);

%4. Consideram urmatoarele
%num�0�0r �0�6ntreg pozitiv: n = 84
%dou�0�0 numere �0�6ntregi: a = 36, b = 60
%num�0�0r complex: z = 3 + 4i
%pentru combinatoric�0�0: N = 6, K = 2
%num�0�0r real: x = 3.6789
%Implementam

%a) Numere prime �0�2i factorizare
%Verifica�0�4i dac�0�0 n este num�0�0r prim.
%Descompune�0�4i n �0�6n factori primi.

%b) Cel mai mare divizor comun �0�2i cel mai mic multiplu comun
%Calcula�0�4i gcd(a, b) �C cel mai mare divizor comun.
%Calcula�0�4i lcm(a, b) �C cel mai mic multiplu comun.

%c) Numere complexe
%Pentru z = 3 + 4i, determina�0�4i:
%partea real�0�0,
%partea imaginar�0�0,
%modulul |z|.
%Calcula�0�4i: z�0�5 �0�2i conjugata lui z.

%d) Factorial, permut�0�0ri, aranjamente, combin�0�0ri
%Pentru N = 6, K = 2, calcula�0�4i:
%N! (factorialul lui 6).
%Num�0�0rul de permut�0�0ri de N elemente: P(N) = N!.
%Num�0�0rul de aranjamente de K elemente din N (f�0�0r�0�0 repeti�0�4ie):
%A(N,K)=N!(N�6�1K)!
%Num�0�0rul de combin�0�0ri de K elemente din N:
%C(N,K)=N!K!(N�6�1K)!

%e) Aproxim�0�0ri �0�2i rotunjiri (pentru x = 3.6789)
%Rotunji�0�4i x la 2 zecimale.
%Aplica�0�4i trunchiere (t�0�0ierea zecimalelor).
%Calcula�0�4i partea �0�6ntreag�0�0 �6�7�0�6n jos�� (floor) �0�2i �6�7�0�6n sus�� (ceil).

% Date de baza
n = 84;
a = 36; b = 60;
z = 3 + 4i;
N = 6; K = 2;
x = 3.6789;

fprintf("=== a) Numere prime si factorizare ===\n");
este_prim = isprime(n);
fprintf("%d este numar prim? %d (1=da,0=nu)\n", n, este_prim);

factori_n = factor(n);
disp("Factorii primi ai lui n sunt:");
disp(factori_n);

fprintf("\n=== b) CMMDC si CMMC ===\n");
d = gcd(a, b);
m = lcm(a, b);
fprintf("gcd(%d, %d) = %d\n", a, b, d);
fprintf("lcm(%d, %d) = %d\n", a, b, m);

fprintf("\n=== c) Numere complexe ===\n");
re_z = real(z);
im_z = imag(z);
mod_z = abs(z);
z2 = z^2;
conj_z = conj(z);

fprintf("z = %g + %gi\n", re_z, im_z);
fprintf("Partea reala = %g, partea imaginara = %g\n", re_z, im_z);
fprintf("|z| = %g\n", mod_z);
fprintf("z^2 = %g + %gi\n", real(z2), imag(z2));
fprintf("conj(z) = %g + %gi\n", real(conj_z), imag(conj_z));

fprintf("\n=== d) Factorial, permutari, aranjamente, combinari ===\n");
fact_N = factorial(N);
P_N = factorial(N);                  % permutari de N elemente
A_NK = factorial(N)/factorial(N-K);  % aranjamente
C_NK = nchoosek(N, K);               % combinari

fprintf("%d! = %d\n", N, fact_N);
fprintf("P(%d) (permutari) = %d\n", N, P_N);
fprintf("A(%d,%d) (aranjamente) = %d\n", N, K, A_NK);
fprintf("C(%d,%d) (combinari) = %d\n", N, K, C_NK);

fprintf("\n=== e) Aproximari si rotunjiri pentru x = %g ===\n", x);
x_round2 = round(x);  % rotunjire la 2 zecimale
x_trunc  = fix(x);       % trunchiere (taie zecimale)
x_floor  = floor(x);     % partea intreaga in jos
x_ceil   = ceil(x);      % partea intreaga in sus

fprintf("round(x,2) = %.2f\n", x_round2);
fprintf("fix(x)     = %g (trunchiat)\n", x_trunc);
fprintf("floor(x)   = %g\n", x_floor);
fprintf("ceil(x)    = %g\n", x_ceil);

%5. Se consider�0�0 matricea p�0�0tratic�0�0:

%A=[2 1 3
%      0 -1 4
%      1 2 0]

%a) Calcula�0�4i determinantul matricei A.
%b) Verifica�0�4i dac�0�0 matricea este inversabil�0�0 (det(A) �� 0).
%c) Dac�0�0 este inversabil�0�0, calcula�0�4i inversa A�6�3�0�1.
%d) Verifica�0�4i rela�0�4ia:
%A�6�6A^�6�11�� I

%unde I este matricea identitate.

%5) Matrice-determinant  si inversa

A = [ 2  1  3;
      0 -1  4;
      1  2  0 ];

disp("Matricea A =");
disp(A);

detA = det(A);
fprintf("det(A) = %.4f\n", detA);

if abs(detA) < 1e-12
    disp("Matricea NU este inversabila (det=0).");
else
    disp("Matricea ESTE inversabila (det != 0).");
    Ainv = inv(A);
    disp("Inversa lui A, A^{-1} =");
    disp(Ainv);

    % verificare A * Ainv ~ I
    I_approx = A * Ainv;
    disp("A * A^{-1} =");
    disp(I_approx);
end

%6.Rezolvarea unui sistem de ecuatii liniare -cu 3 necunoscute

%Consider�0�0m sistemul de ecua�0�4ii liniare:
%2x + y - z = 1
%-3x + 4y + 2z = 7
%x - 2y + 5z = -4

%a) Scrie�0�4i sistemul �0�6n form�0�0 matricial�0�0:
% A - X = b

%unde:
%A este matricea coeficien�0�4ilor,
%        x
%X = [y]
%        z
%b este vectorul termenilor liberi.

%b) Implementa�0�4i matricea �0�2i vectorul �0�6n:
%Octave/MATLAB
%Python (folosind NumPy)
%c) Rezolva�0�4i sistemul folosind comanda:
%�0�6n Octave: x = A\b;
%�0�6n Python: x = np.linalg.solve(A, b)
%d) Afi�0�2a�0�4i solu�0�4ia (valorile lui x, y, z) cu mesaje clare.
%e) Verifica�0�4i solu�0�4ia calcul�0�9nd (sau A @ x �0�6n Python) �0�2i ar�0�0ta�0�4i c�0�0 rezultatul este vectorul b.

% Aplicatie: rezolvarea unui sistem de 3 ecuatii liniare
% Sistem:
% 2x +  y -  z =  1
% -3x + 4y + 2z = 7
%  x - 2y + 5z = -4

% a) Scriem matricea A si vectorul b
A = [  2   1  -1;
       -3  4   2;
        1 -2   5 ];
b = [ 1; 7; -4 ];
disp("Matricea A =");
disp(A);
disp("Vectorul b =");
disp(b);

% c) Rezolvam sistemul A * X = b
X = A \ b;      % operatorul \ face rezolvarea sistemului

% d) Afisam solutia
x = X(1);
y = X(2);
z = X(3);
fprintf("Solutia sistemului este:\n");
fprintf("x = %g\n", x);
fprintf("y = %g\n", y);
fprintf("z = %g\n", z);

% e) Verificare: A * X ar trebui sa fie egal cu b
b_verif = A * X;
disp("A * X (pentru verificare) =");
disp(b_verif);
fprintf("\nDaca A*X este (aproape) egal cu b, atunci solutia este corecta.\n");

%7.Functii trigonometrice :Pentru unghiul �� = 45��:

%a)Converte�0�2te unghiul din grade �0�6n radiani.
%b)Calculeaz�0�0 sin(��), cos(��) �0�2i tan(��).
%c) Folose�0�2te func�0�4iile inverse: arcsin, arccos, arctan pentru valorile ob�0�4inute.
%d) Afi�0�2eaz�0�0 toate rezultatele cu 4 zecimale.

% unghiul in grade
theta_deg = 45;

% a) conversie in radiani
theta_rad = deg2rad(theta_deg);

% b) functii trigonometrice (in radiani)
sin_val = sin(theta_rad);
cos_val = cos(theta_rad);
tan_val = tan(theta_rad);

% c) functii inverse (rezultat in radiani)
arcsin_val = asin(sin_val);
arccos_val = acos(cos_val);
arctan_val = atan(tan_val);

% convertim inapoi in grade pentru interpretare
arcsin_deg = rad2deg(arcsin_val);
arccos_deg = rad2deg(arccos_val);
arctan_deg = rad2deg(arctan_val);

% d) afisare rezultate cu 4 zecimale
fprintf('�� �0�6n grade = %d\n', theta_deg);
fprintf('a) �� �0�6n radiani = %.4f\n\n', theta_rad);
fprintf('b) sin(��) = %.4f\n', sin_val);
fprintf('   cos(��) = %.4f\n', cos_val);
fprintf('   tan(��) = %.4f\n\n', tan_val);
fprintf('c) arcsin(sin(��)) = %.4f��\n', arcsin_deg);
fprintf('   arccos(cos(��)) = %.4f��\n', arccos_deg);
fprintf('   arctan(tan(��)) = %.4f��\n', arctan_deg);

%10. Rezolv problema in 4 moduri
%definire vectorial�0�0
%procedura function
%func�0�4ie anonymous
%comanda polyval

% Aplicatie: calculul valorilor functiei f(x) = x^4 - 5x^3 + 2x + 3
% pe intervalul [-2, 2] cu pas 0.5

% vectorul de x
x = -2:0.5:2;
%% 1) Metoda vectoriala (expresie directa)
y1 = x.^4 - 5*x.^3 + 2*x + 3;

%% 2) Metoda cu functie (fisier separat f_poly.m)
y2 = f_poly(x);

%% 3) Metoda cu functie anonymous
f = @(x) x.^4 - 5*x.^3 + 2*x + 3;
y3 = f(x);

%% 4) Metoda cu polyval
% coeficientii polinomului x^4 - 5x^3 + 0*x^2 + 2x + 3
coef = [1 -5 0 2 3];
y4 = polyval(coef, x);

%% Afisare (optional)
disp('x =');  disp(x);
disp('y1 (vectorial) ='); disp(y1);
disp('y2 (function)   ='); disp(y2);
disp('y3 (anonymous)  ='); disp(y3);
disp('y4 (polyval)    ='); disp(y4);

% Definim functia
f = @(x) x.^2 + 3.*x;
% Calculeaza integral�0�0
I = integral(f, 0, 2);
fprintf('Valoarea integralei este: %.4f\n', I);

% functia
f = @(x, y) x + y;
% calcul integrala dubla in zona [0,1] x [0,2]
I = integral2(f, 0, 1, 0, 2);
fprintf('Valoarea integralei duble este: %.4f\n', I);


