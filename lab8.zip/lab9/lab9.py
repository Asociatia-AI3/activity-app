import numpy as np
import math

#1. Folosind valoarea x = 5.7, calculați și afișați:
#a) rădăcina pătrată din x: √x
#b) exponențiala lui x: eˣ
#c) logaritmul natural din x: ln(x)
#d) logaritmul zecimal din x: log₁₀(x)
#e) logaritmul în baza 2 din x: log₂(x)

#2.Folosind y = -3, calculați și afișați:
#a) modulul lui y: |y|
#b) semnul lui y,(−1 dacă e negativ, 0 dacă e 0, +1 dacă e pozitiv)

#3.Folosind a = 2 și b = 5, calculați și afișați:
#a) puterea lui a la b, adică:
#a^b=2^5

print("1. x=5.7")
x = 5.7
sqrt_x = math.sqrt(x)
exp_x = math.exp(x)
ln_x = math.log(x)
log10_x = math.log10(x)
log2_x = math.log2(x)
print(f"√x={sqrt_x}, eˣ={exp_x}, ln(x)={ln_x}, log₁₀(x)={log10_x}, log₂(x)={log2_x}")

print("\n2. y=-3")
y = -3
abs_y = abs(y)
sign_y = (y > 0) - (y < 0)
print(f"|y|={abs_y}, sign(y)={sign_y}")

print("\n3. a=2, b=5")
a = 2
b = 5
power_ab = a ** b
print(f"a^b={power_ab}")

#4. Consideram urmatoarele 
#număr întreg pozitiv: n = 84 
#două numere întregi: a = 36, b = 60 
#număr complex: z = 3 + 4i 
#pentru combinatorică: N = 6, K = 2 
#număr real: x = 3.6789 
#Implementam

#a) Numere prime și factorizare 
#Verificați dacă n este număr prim. 
#Descompuneți n în factori primi. 

#b) Cel mai mare divizor comun și cel mai mic multiplu comun 
#Calculați gcd(a, b) – cel mai mare divizor comun. 
#Calculați lcm(a, b) – cel mai mic multiplu comun. 

#c) Numere complexe 
#Pentru z = 3 + 4i, determinați: 
#partea reală, 
#partea imaginară, 
#modulul |z|. 
#Calculați: z² și conjugata lui z. 

#d) Factorial, permutări, aranjamente, combinări 
#Pentru N = 6, K = 2, calculați: 
#N! (factorialul lui 6). 
#Numărul de permutări de N elemente: P(N) = N!. 
#Numărul de aranjamente de K elemente din N (fără repetiție): 
#A(N,K)=N!(N−K)! 
#Numărul de combinări de K elemente din N: 
#C(N,K)=N!K!(N−K)!

#e) Aproximări și rotunjiri (pentru x = 3.6789) 
#Rotunjiți x la 2 zecimale. 
#Aplicați trunchiere (tăierea zecimalelor). 
#Calculați partea întreagă „în jos” (floor) și „în sus” (ceil). 

print("\n4. n=84, a=36, b=60, z=3+4i, N=6, K=2, x=3.6789")
n = 84
a = 36
b = 60
z = 3 + 4j
N = 6
K = 2
x = 3.6789
print("a) Numere prime si factorizare")
def is_prime(num):
    if num <= 1:
        return False
    for i in range(2, int(math.sqrt(num)) + 1):
        if num % i == 0:
            return False
    return True

def prime_factors(num):
    factors = []
    for i in range(2, num + 1):
        while num % i == 0:
            factors.append(i)
            num //= i
    return factors

print(f"Is {n} prime? {bool(is_prime(n))}")
print(f"Prime factors of {n}: {prime_factors(n)}")

print("\nb) Cel mai mare divizor comun si cel mai mic multiplu comun")
def gcd(x, y):
    while y:
        x, y = y, x % y
    return x

def lcm(x, y):
    return x * y // gcd(x, y)

print(f"gcd({a}, {b}) = {gcd(a, b)}")
print(f"lcm({a}, {b}) = {lcm(a, b)}")

print("\nc) Numere complexe")
print(f"Partea reala a lui z: {z.real}")
print(f"Partea imaginara a lui z: {z.imag}")
print(f"Modulul |z|: {abs(z)}")
print(f"z^2: {z**2}")
print(f"Conjugata lui z: {z.conjugate()}")

print("\nd) Factorial, permutari, aranjamente, combinari")
def factorial(num):
    if num == 0 or num == 1:
        return 1
    result = 1
    for i in range(2, num + 1):
        result *= i
    return result
def permutations(num):
    return factorial(num)
def arrangements(n, k):
    return factorial(n) // factorial(n - k)
def combinations(n, k):
    return factorial(n) // (factorial(k) * factorial(n - k))
print(f"{N}! = {factorial(N)}")
print(f"P({N}) = {permutations(N)}")
print(f"A({N},{K}) = {arrangements(N, K)}")
print(f"C({N},{K}) = {combinations(N, K)}")

print("\ne) Aproximari si rotunjiri")
print(f"Rotunjit la 2 zecimale: {round(x, 2)}")
print(f"Trunchiere: {math.trunc(x)}")
print(f"Partea intreaga in jos (floor): {math.floor(x)}")
print(f"Partea intreaga in sus (ceil): {math.ceil(x)}")

#5. Se consideră matricea pătratică: 

#A=[2 1 3
#      0 -1 4
#      1 2 0]

#a) Calculați determinantul matricei A. 
#b) Verificați dacă matricea este inversabilă (det(A) ≠ 0). 
#c) Dacă este inversabilă, calculați inversa A⁻¹. 
#d) Verificați relația: 
#A⋅A^−1≈ I

#unde I este matricea identitate. 

print("\n5. Matricea A")
A = np.array([[2, 1, 3],
                [0, -1, 4],
                [1, 2, 0]], dtype=float)

print("a) Determinantul matricei A")
det_A = np.linalg.det(A)
print(f"Determinantul matricei A: {det_A}")

print("\nb) Verificarea daca matricea este inversabila")
if det_A != 0:
    print("Matricea A este inversabila.")
    print("\nc) Calcularea inversei A^-1")
    A_inv = np.linalg.inv(A)
    print(f"Inversa matricei A:\n{A_inv}")
    print("\nd) Verificarea relatiei A * A^-1 ≈ I")
    I_approx = np.dot(A, A_inv)
    print(f"A * A^-1:\n{I_approx}")
else:
    print("Matricea A nu este inversabila.")

#6.Rezolvarea unui sistem de ecuatii liniare -cu 3 necunoscute

#Considerăm sistemul de ecuații liniare:
#2x + y - z = 1
#-3x + 4y + 2z = 7
#x - 2y + 5z = -4

#a) Scrieți sistemul în formă matricială:
# A - X = b

#unde:
#A este matricea coeficienților,
#        x
#X = [y]
#        z
#b este vectorul termenilor liberi.

#b) Implementați matricea și vectorul în:
#Octave/MATLAB
#Python (folosind NumPy)
#c) Rezolvați sistemul folosind comanda:
#în Octave: x = A\b;
#în Python: x = np.linalg.solve(A, b)
#d) Afișați soluția (valorile lui x, y, z) cu mesaje clare.
#e) Verificați soluția calculând (sau A @ x în Python) și arătați că rezultatul este vectorul b.

print("\n6. Rezolvarea unui sistem de ecuatii liniare")
A = np.array([ 
    [ 2,  1, -1], 
    [-3,  4,  2], 
    [ 1, -2,  5] 
], dtype=float) 

b = np.array([1, 7, -4], dtype=float) 
print("Matricea A =") 
print(A) 
print("\nVectorul b =") 
print(b) 

# c) Rezolvam sistemul A * X = b 
print("\nRezolvarea sistemului A * X = b")
X = np.linalg.solve(A, b)
print(f"Soluția sistemului de ecuatii: x={X[0]}, y={X[1]}, z={X[2]}")
# e) Verificam solutia calculand A @ X
b_check = np.dot(A, X)
print("\nVerificarea solutiei (A @ X):")
print(b_check)
print(f"Vectorul b: {b}")
# Aratam ca rezultatul este vectorul b
if np.allclose(b_check, b):
    print("Verificare reusita: A @ X este egal cu b.")
else:
    print("Verificare esuata: A @ X nu este egal cu b.")

#7.Functii trigonometrice :Pentru unghiul θ = 45°:

#a)Convertește unghiul din grade în radiani.
#b)Calculează sin(θ), cos(θ) și tan(θ).
#c) Folosește funcțiile inverse: arcsin, arccos, arctan pentru valorile obținute.
#d) Afișează toate rezultatele cu 4 zecimale.

print("\n7. Functii trigonometrice pentru θ = 45°")
theta_deg = 45
theta_rad = math.radians(theta_deg)
sin_theta = math.sin(theta_rad)
cos_theta = math.cos(theta_rad)
tan_theta = math.tan(theta_rad)
arcsin_val = math.degrees(math.asin(sin_theta))
arccos_val = math.degrees(math.acos(cos_theta))
arctan_val = math.degrees(math.atan(tan_theta))
print(f"θ în radiani: {theta_rad:.4f}")
print(f"sin(θ) = {sin_theta:.4f}, cos(θ) = {cos_theta:.4f}, tan(θ) = {tan_theta:.4f}")
print(f"arcsin(sin(θ)) = {arcsin_val:.4f}°, arccos(cos(θ)) = {arccos_val:.4f}°, arctan(tan(θ)) = {arctan_val:.4f}°")

#8. Crearea unor functii de transformare din coordonate cartesiene în polare și invers folosing cart2pol și pol2cart.
print("\n8. Transformare coordonate carteziene în polare și invers")
def cart2pol(x, y):
    r = math.sqrt(x**2 + y**2)
    theta = math.atan2(y, x)
    return r, theta

def pol2cart(r, theta):
    x = r * math.cos(theta)
    y = r * math.sin(theta)
    return x, y

x_cart, y_cart = 3, 4
r, theta = cart2pol(x_cart, y_cart)
print(f"Coordonate carteziene ({x_cart}, {y_cart}) în coordonate polare: (r={r:.4f}, θ={theta:.4f} radiani)")
x_back, y_back = pol2cart(r, theta)
print(f"Coordonate polare (r={r:.4f}, θ={theta:.4f} radiani) înapoi în coordonate carteziene: ({x_back:.4f}, {y_back:.4f})")

#9 Coordonate carteziene sferice și invers folosind cart2sph și sph2cart.
from hyperspherical import cartesian2spherical, spherical2cartesian
print("\n9. Transformare coordonate carteziene sferice și invers")

cartesian_coordinates = np.array([3, 4, 5], dtype=float)
spherical_coordinates = cartesian2spherical(cartesian_coordinates)
print(f"Coordonate carteziene {cartesian_coordinates} în coordonate sferice: {spherical_coordinates}")
cartesian_back = spherical2cartesian(spherical_coordinates)
print(f"Coordonate sferice {spherical_coordinates} înapoi în coordonate carteziene: {cartesian_back}")

from scipy.integrate import quad 
# definim functia 
def f(x): 
    return x**2 + 3*x 
# calculam integrala 
result, _ = quad(f, 0, 2) 
print(f"Valoarea integralei este: {result:.4f}") 

from scipy.integrate import dblquad 

# functia de integrat 
def f(y, x): 
    return x + y  # observă ordinea: mai întâi y, apoi x 
# calcul integrala 
result, _ = dblquad(f, 0, 1, lambda x: 0, lambda x: 2) 
print(f"Valoarea integralei duble este: {result:.4f}") 