function y = f_poly(x)
       y = x.^4 - 5*x.^3 + 2*x + 3;
endfunction
