import numpy as np

# P1
A = np.array([[0, 2, 0, 1],
            [1, 2, 3, 4],
            [4, -3, 0, 1],
            [3, 1, 4, 2]], dtype=float)

B = np.random.rand(4, 4)
print("A + B =\n", A + B)
print("A - B =\n", A - B)
print("A * B =\n", A * B)
print("5 + A =\n", 5 + A)
print("A ^ 10 =\n", np.linalg.matrix_power(A, 10))
print("e ^ A =\n", np.linalg.matrix_power(np.exp(1) * np.eye(4), A))
print(" 2 ^ A =\n", np.linalg.matrix_power(2 * np.eye(4), A))

# P2
A = np.array([[1, 2, 3],
            [4, 5, 6],
            [7, 8, 9]], dtype=float)

B = np.array([[7, 8, 9],
            [4, 5, 6],
            [1, 2, 3]], dtype=float)

print("\nA. * B =\n", np.dot(A, B))
print("A . / B =\n", A / B)
print("A . ^ B =\n", A ** B)

# P3 
# x + 2y + 3z = 9
# 4x + 5y + 6z = 0
# 7x + 8y - 1z = 1
A = np.array([[1, 2, 3],
            [4, 5, 6],
            [7, 8, -1]], dtype=float)
b = np.array([9, 0, 1], dtype=float)
# Folosing operatorul \ de impartire la stanga
x = np.linalg.solve(A, b)
print("\nSoluția sistemului de ecuații este:")
print(x)

# P4
# x + 2y + 3z = 1
# 4x + 5y + 6z = 1
A = np.array([[1, 2, 3],
            [4, 5, 6]], dtype=float)
b = np.array([1, 1], dtype=float)

# folosind operatorul / de impartire la dreapta si \ de impartire la stanga
print("\nSoluția aproximativă a sistemului de ecuații este:")
x_right = np.linalg.lstsq(A, b, rcond=None)[0]
print("Folosind operatorul / de împărțire la dreapta:")
print(x_right)
x_left = np.linalg.lstsq(A.T, b, rcond=None)[0]
print("Folosind operatorul \\ de împărțire la stânga:")
print(x_left)

# calculati integrala de la 1 la 3 din (2x^3 - 4x + 1) dx
from scipy import integrate
def f(x):
    return 2 * x**3 - 4 * x + 1
result, error = integrate.quad(f, 1, 3)
print("\nValoarea integralei este:", result)

# calculati integrala dubla din (x^2 +y) dA
def integrand(y, x):
    return x**2 + y
x_lower, x_upper = 0, 2
y_lower, y_upper = 0, 1
result_double, error_double = integrate.dblquad(integrand, x_lower, x_upper, lambda x: y_lower, lambda x: y_upper)
print("\nValoarea integralei duble este:", result_double)

# sa se calc val functiei f(x) = x^3 - 3x^2 + 2x - 5 pentru x e [-4, 4] cu pas k 0.5
# rezolva problema in 4 moduri: definire vectoriala, procdura function, functie anonymous, comanda polyval
import numpy as np
x = np.arange(-4, 4.5, 0.5)
# 1. Definire vectorială
f_vectorial = x**3 - 3*x**2 + 2*x - 5
print("\nValori folosind definire vectorială:")
print(f_vectorial)
# 2. Procedură function
def f_function(x):
    return x**3 - 3*x**2 + 2*x - 5
f_func_values = f_function(x)
print("\nValori folosind procedură function:")
print(f_func_values)
# 3. Funcție anonymous
f_anonymous = lambda x: x**3 - 3*x**2 + 2*x - 5
f_anon_values = f_anonymous(x)
print("\nValori folosind funcție anonymous:")
print(f_anon_values)    
# 4. Comanda polyval
coefficients = [1, -3, 2, -5]
f_polyval_values = np.polyval(coefficients, x)
print("\nValori folosind comanda polyval:")
print(f_polyval_values)
